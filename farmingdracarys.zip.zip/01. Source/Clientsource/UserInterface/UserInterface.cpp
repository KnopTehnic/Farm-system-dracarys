//Hinzuf�gen unter: initServerStateChecker();

#ifdef ENABLE_ANTI_MULTIPLE_FARM
	initAntiMultipleFarmMethods();
#endif
