//Hinzuf�gen am Ende der Datei vor - #pragma pack(pop)

#ifdef ENABLE_ANTI_MULTIPLE_FARM
enum EAntiMultipleFarmConfigs
{
	MA_LENGTH = 255,
	MULTIPLE_FARM_MAX_ACCOUNT = 2,
};
#endif
